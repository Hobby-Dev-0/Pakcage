from userbot.config import Development as Config
from userbot.config import Var as Config
from userbot.AndencentoConfig import Development as Config
from userbot.AndencentoConfig import Var as Config

Var = Config
